Manuel Aragon
CSCE 4290 NATURAL LANGUAGE PROCESSING
Project 1

Written using Python3 3.10.6


#HOW TO RUN USING JUYPTER NOTEBOOK ON LINUX
1.run command 'jupyter notebook'
2.navigate to the ipynb file
3.run whole notebook
